import React from "react";

const Tomato = React.forwardRef(() => {
  return <button>hihi</button>;
});

export default Tomato;
