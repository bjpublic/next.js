const Error = () => {
  return <p>에러가 발생 했습니다.</p>;
};

export default Error;
