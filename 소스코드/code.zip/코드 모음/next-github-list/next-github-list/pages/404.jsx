const NotFound = () => {
  return <p>안녕하세요. 404 페이지 입니다.</p>;
};

export default NotFound;
